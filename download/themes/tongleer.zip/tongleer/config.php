<?php
/**
 * 主题配置
 */
$config_follow_qrcode="http://me.tongleer.com/content/uploadfile/201706/008b1497454448.png";
$config_headImgUrl='https://cambrian-images.cdn.bcebos.com/39ceafd81d6813a014e747db4aa6f0eb_1524963877208.jpeg';
$config_headBg='http://api.tongleer.com/picturebed/img/bg.jpg';
$config_favicon='http://www.tongleer.com/wp-content/themes/D8/img/favicon.png';
$config_nav='<li><a href=http://baidu.com target=_blank></a></li><li><a href=http://qq.com target=_blank></a></li>';
$config_nickname='快乐贰呆';
$config_home_name='主页';
$config_home_link='http://www.tongleer.com';
$config_album_name='相册';
$config_album_link='javascript:;';
$config_other_1_name='^_^';
$config_other_1_link='javascript:;';
?>